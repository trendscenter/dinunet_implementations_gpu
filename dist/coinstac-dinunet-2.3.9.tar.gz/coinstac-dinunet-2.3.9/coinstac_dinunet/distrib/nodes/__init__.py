from .local import COINNLocal
from .remote import COINNRemote
